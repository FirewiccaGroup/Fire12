# Mocha In the Browser

A super simple example of how [Mocha](http://visionmedia.github.com/mocha/) tests
can be executed in the browser. A great way to start is cloning this project and
working through the [String Calculator Kata](http://osherove.com/tdd-kata-1/).
Open up the public/index.html file in a browser to see the JavaScript object
used by the page.

### Integrating it into your project

Copy the spec directory into your project. Make sure the runner.html file has all
the right paths.
